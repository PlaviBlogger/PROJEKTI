#ifndef FW_PKGS_HPP
#define FW_PKGS_HPP

#include <Arduino.h>
#include <stdint.h>

// Paketni format (jednostavan i jasan) � kompaktan i bez paddinga
#pragma pack(push, 1)

using pkg_magic_t = uint16_t;
using pkg_crc_t   = uint16_t;

static constexpr pkg_magic_t PKG_MAGIC = 0xABCD;

// Opcioni header (mo�e� pro�irivati po potrebi)
struct pkg_header_t {
  pkg_magic_t magic;
  uint8_t version;   // npr. 1
};

// Master -> Slave payload (zahtev)
struct payload_m2s_t {
  uint8_t servo_angle;  // 0..180
};

// Slave -> Master payload (odgovor)
struct payload_s2m_t {
  uint8_t status;       // 1=OK, 0=ERR (po �elji pro�iri)
};

// Master -> Slave ceo paket
struct pkg_m2s_t {
  pkg_header_t header;
  payload_m2s_t payload;
  pkg_crc_t crc;
};

// Slave -> Master ceo paket
struct pkg_s2m_t {
  pkg_header_t header;
  payload_s2m_t payload;
  pkg_crc_t crc;
};

#pragma pack(pop)

// Pomocne konstante
static constexpr uint8_t PKG_VERSION = 1;

#endif // FW_PKGS_HPP
