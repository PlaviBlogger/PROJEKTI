#ifndef CRC16_HPP
#define CRC16_HPP

#include <stdint.h>
#include <stddef.h>

// CRC-16/IBM (polinom 0xA001), init 0xFFFF (klasični Modbus stil)
class CRC16 {
public:
  CRC16() : crc_(0xFFFF) {}

  // Dodaj jedan bajt
  CRC16& add(uint8_t b) {
    crc_ ^= b;
    for (uint8_t i = 0; i < 8; ++i) {
      if (crc_ & 1) crc_ = (crc_ >> 1) ^ 0xA001;
      else          crc_ = (crc_ >> 1);
    }
    return *this;
  }

  // Dodaj niz bajtova
  CRC16& add(const uint8_t* data, size_t len) {
    for (size_t i = 0; i < len; ++i) add(data[i]);
    return *this;
  }

  // Dodaj proizvoljnu POD/struct vrednost bez type-traits (na našu odgovornost)
  template<typename T>
  CRC16& add(const T& obj) {
    const uint8_t* p = reinterpret_cast<const uint8_t*>(&obj);
    return add(p, sizeof(T));
  }

  uint16_t get_crc() const { return crc_; }

private:
  uint16_t crc_;
};

#endif // CRC16_HPP
