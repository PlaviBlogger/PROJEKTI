#ifndef FW_PKGS_HPP
#define FW_PKGS_HPP

#include <Arduino.h>
#include <stdint.h>

#pragma pack(push, 1)
using pkg_magic_t = uint16_t;
using pkg_crc_t   = uint16_t;

static constexpr pkg_magic_t PKG_MAGIC = 0xABCD;

struct pkg_header_t {
  pkg_magic_t magic;
  uint8_t     version;
};

struct payload_m2s_t { uint8_t servo_angle; };
struct payload_s2m_t { uint8_t status; };

struct pkg_m2s_t { pkg_header_t header; payload_m2s_t payload; pkg_crc_t crc; };
struct pkg_s2m_t { pkg_header_t header; payload_s2m_t payload; pkg_crc_t crc; };
#pragma pack(pop)

static constexpr uint8_t PKG_VERSION = 1;

#endif
