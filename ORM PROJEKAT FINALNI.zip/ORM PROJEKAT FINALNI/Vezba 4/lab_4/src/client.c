/* 
    ********************************************************************
    Odsek:          Elektrotehnika i racunarstvo
    Departman:      Racunarstvo i automatika
    Katedra:        Racunarska tehnika i racunarske komunikacije (RT-RK)
    Predmet:        Osnovi Racunarskih Mreza 1
    Godina studija: Treca (III)
    Skolska godina: 2021/22
    Semestar:       Zimski (V)
    
    Ime fajla:      client.c
    Opis:           TCP/IP klijent
    
    Platforma:      Raspberry Pi 2 - Model B
    OS:             Raspbian
    ********************************************************************
*/

#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>

#define DEFAULT_BUFLEN 1024
#define DEFAULT_PORT   27015

int main(int argc , char *argv[])
{
    int sock;
    struct sockaddr_in server;
    char poruka_klijenta[DEFAULT_BUFLEN], odgovor_servera[DEFAULT_BUFLEN];

    // Create socket
    sock = socket(AF_INET , SOCK_STREAM , 0);
    if (sock == -1)
    {
        printf("Nije moguce kreirati socket");
        return 1;
    }
    puts("Socket kreiran");

    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(DEFAULT_PORT);

    // Connect to remote server
    if (connect(sock , (struct sockaddr *)&server , sizeof(server)) < 0)
    {
        perror("Greska prilikom povezivanja na server...");
        return 1;
    }

    puts("Konektovan na server!\n");

    while (1)
    {
        printf("-> ");
        fflush(stdout);

        if (fgets(poruka_klijenta, DEFAULT_BUFLEN, stdin) == NULL)
            break;

        // Uklanjanje newline karaktera
        poruka_klijenta[strcspn(poruka_klijenta, "\n")] = 0;

        // Prekid programa
        if (strcmp(poruka_klijenta, "exit") == 0)
            break;

        // Slanje poruke serveru
        if (send(sock , poruka_klijenta , strlen(poruka_klijenta) , 0) < 0)
        {
            puts("Slanje neuspjesno");
            break;
        }

        // Primanje odgovora od servera
        int preuzimanje_odgovora_servera = recv(sock , odgovor_servera , DEFAULT_BUFLEN , 0);
        if (preuzimanje_odgovora_servera < 0)
        {
            puts("Greska pri preuzimanju odgovora sa servera");
            break;
        }

        odgovor_servera[preuzimanje_odgovora_servera] = '\0';
        printf("Server: %s\n", odgovor_servera);
    }

    close(sock);
    return 0;
}
