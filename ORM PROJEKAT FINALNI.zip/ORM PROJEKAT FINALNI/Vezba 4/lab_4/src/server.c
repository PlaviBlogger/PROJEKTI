/* 
    ********************************************************************
    Odsek:          Elektrotehnika i racunarstvo
    Departman:      Racunarstvo i automatika
    Katedra:        Racunarska tehnika i racunarske komunikacije (RT-RK)
    Predmet:        Osnovi Racunarskih Mreza 1
    Godina studija: Treca (III)
    Skolska godina: 2021/22
    Semestar:       Zimski (V)
    
    Ime fajla:      server.c
    Opis:           TCP/IP server
    
    Platforma:      Raspberry Pi 2 - Model B
    OS:             Raspbian
    ********************************************************************
*/

#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<stdlib.h>

#define DEFAULT_BUFLEN 1024
#define DEFAULT_PORT   27015
#define MAX_PORUKA   100

typedef struct {
    char posiljalac[50];
    char primalac[50];
    char sadrzaj_poruke[512];
    int stanje_poruke;
} PORUKA;

PORUKA inbox[MAX_PORUKA];
int brojac_poruka = 0;
char trenutni_korisnik[50] = "";

void posalji_odgovor(int client_sock, const char* odgovor) {
    send(client_sock, odgovor, strlen(odgovor), 0);
}

void unesi_komandu(int client_sock, char* unesena_komanda) {
    char komanda[20];
    sscanf(unesena_komanda, "%s", komanda);

    if (strcmp(komanda, "Login") == 0) {
        sscanf(unesena_komanda, "%*s %s", trenutni_korisnik);
        posalji_odgovor(client_sock, "Uspjesno ste se ulogovali");
    }
    else if (strcmp(komanda, "Logout") == 0) {
        trenutni_korisnik[0] = '\0';
        posalji_odgovor(client_sock, "Uspjesno ste se izlgovali");
    }
    else if (strcmp(komanda, "Send") == 0) {
        char primalac[50], poruka_pom[512];
        if (sscanf(unesena_komanda, "%*s %s %[^\n]", primalac, poruka_pom) == 2) {
            if (brojac_poruka < MAX_PORUKA) {
                strcpy(inbox[brojac_poruka].posiljalac, trenutni_korisnik);
                strcpy(inbox[brojac_poruka].primalac, primalac);
                strcpy(inbox[brojac_poruka].sadrzaj_poruke, poruka_pom);
                inbox[brojac_poruka].stanje_poruke = 1;
                brojac_poruka++;
                posalji_odgovor(client_sock, "Poruka poslata");
            } else {
                posalji_odgovor(client_sock, "Inbox je pun. Dostigli ste ogranicenje od 100 poruka");
            }
        } else {
            posalji_odgovor(client_sock, "Pogresno ste zadali komandu");
        }
    }
    else if (strcmp(komanda, "Check") == 0) {
        int pom = 0;
        for (int i = 0; i < brojac_poruka; i++) {
            if (inbox[i].stanje_poruke && strcmp(inbox[i].primalac, trenutni_korisnik) == 0) {
                pom = 1;
                break;
            }
        }
        posalji_odgovor(client_sock, pom ? "Imate poruka" : "Nemate poruka");
    }
    else if (strcmp(komanda, "Stat") == 0) {
        int br_poruka = 0;
        for (int i = 0; i < brojac_poruka; i++) {
            if (inbox[i].stanje_poruke && strcmp(inbox[i].primalac, trenutni_korisnik) == 0)
                br_poruka++;
        }
        char odgovor[100];
        snprintf(odgovor, sizeof(odgovor), "Imate %d poruka", br_poruka);
        posalji_odgovor(client_sock, odgovor);
    }
    else if (strcmp(komanda, "Delete") == 0) {
        int id;
        if (sscanf(unesena_komanda, "%*s %d", &id) == 1 && id >= 0 && id < brojac_poruka &&
            inbox[id].stanje_poruke && strcmp(inbox[id].primalac, trenutni_korisnik) == 0) {
            inbox[id].stanje_poruke = 0;
            posalji_odgovor(client_sock, "Poruka iybrisana");
        } else {
            posalji_odgovor(client_sock, "Pogresan ID poruke");
        }
    }
    else if (strcmp(komanda, "Clean") == 0) {
        int deleted = 0;
        for (int i = 0; i < brojac_poruka; i++) {
            if (inbox[i].stanje_poruke && strcmp(inbox[i].primalac, trenutni_korisnik) == 0) {
                inbox[i].stanje_poruke = 0;
                deleted++;
            }
        }
        char odgovor[100];
        snprintf(odgovor, sizeof(odgovor), "Obrisano je %d poruka", deleted);
        posalji_odgovor(client_sock, odgovor);
    }
    else if (strcmp(komanda, "Receive") == 0) {
        char odgovor[DEFAULT_BUFLEN] = "";
        for (int i = 0; i < brojac_poruka; i++) {
            if (inbox[i].stanje_poruke && strcmp(inbox[i].primalac, trenutni_korisnik) == 0) {
                char line[600];
                snprintf(line, sizeof(line), "[%d] Od: %s - %s\n", i, inbox[i].posiljalac, inbox[i].sadrzaj_poruke);
                strncat(odgovor, line, sizeof(odgovor) - strlen(odgovor) - 1);
            }
        }
        posalji_odgovor(client_sock, strlen(odgovor) > 0 ? odgovor : "Nema poruka za prijem");
    }
    else {
        posalji_odgovor(client_sock, "Nepoznata komanda");
    }
}

int main(int argc , char *argv[])
{
    int socket_desc, client_sock, c, read_size;
    struct sockaddr_in server, client;
    char poruka_klijenta[DEFAULT_BUFLEN];

    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1) {
        printf("Nije moguće kreirati socket");
        return 1;
    }
    puts("Socket kreiran");

    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(DEFAULT_PORT);

    if (bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0) {
        perror("Bindovanje nije uspjelo");
        return 1;
    }
    puts("Bind uspješno izvršeno");

    listen(socket_desc , 3);
    puts("Čekanje za dolazeće konekcije...");

    c = sizeof(struct sockaddr_in);
    client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c);
    if (client_sock < 0) {
        perror("Accept neuspješan");
        return 1;
    }
    puts("Konekcija prihvaćena");

    while ((read_size = recv(client_sock , poruka_klijenta , DEFAULT_BUFLEN , 0)) > 0)
    {
        poruka_klijenta[read_size] = '\0';
        unesi_komandu(client_sock, poruka_klijenta);
    }

    if(read_size == 0)
        puts("Klijent diskonektovan");
    else if(read_size == -1)
        perror("Recv neuspješan");

    return 0;
}


